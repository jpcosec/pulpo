"""E-commerce Example - Operations.

Operations for order management, fulfillment, and payment processing.
Demonstrates parallelization and sequential dependencies.
"""
