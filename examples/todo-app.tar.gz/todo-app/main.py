#!/usr/bin/env python3
"""Custom Pulpo CLI entry point for todo-app with model discovery.

This file exists as a workaround for Pulpo's model discovery limitation.
Pulpo looks for models/operations in specific directories, but we organize
them under src/models and src/operations. This entry point imports all
models and operations before the Pulpo CLI starts, ensuring they're
registered with the framework.

Once Pulpo supports custom directory patterns, this wrapper can be replaced
with the standard `pulpo` command.
"""

import sys

# Ensure this directory is in the path
sys.path.insert(0, '/home/jp/todo-app')
sys.path.insert(0, '/home/jp/pulpo')

# Import all models to register them with Pulpo BEFORE CLI starts
from src.models.status import TaskStatus, TaskStatusEnum
from src.models.category import Category
from src.models.date import DateRange
from src.models.alarm import Alarm, RecurrencePattern
from src.models.task import Task

# Import all operations to register them with Pulpo
from src.operations.task_analysis import (
    check_needed_tasks,
    next_by_urgency,
    next_by_importance,
    next_combined,
)
from src.operations.document_loader import (
    load_markdown,
    load_json,
    extract_code_todos,
)

# Now run the Pulpo CLI
from core.cli.main import main

if __name__ == "__main__":
    main()
