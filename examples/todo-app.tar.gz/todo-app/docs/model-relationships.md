# Model Relationships

```mermaid
erDiagram
    TaskStatus {}
    Category {}
    Alarm {}
    Task {}
    Task ||--o{ Task : "dependencies"
```

## Legend

- **Entities**: Data models (@datamodel decorated classes)
- **Relationships**: How models connect
  - `||--o{` = One-to-many (parent has many children)
  - `}o--||` = Many-to-one (child belongs to parent)
- **Labels**: Field names that create the relationships

## Model Composition

### Task

- **has many** `Task` via field `dependencies`
- **has many** `Task` via field `subtasks`

```

## Model Details

### TaskStatus

Custom task status for user-defined workflows

**Fields**:

- `id`: typing.Optional[beanie.odm.fields.PydanticObjectId] - MongoDB document ObjectID
- `revision_id`: typing.Optional[uuid.UUID] - None
- `name`: <class 'str'> - Status name (e.g., 'On Hold', 'Blocked')
- `color`: <class 'str'> - Hex color for UI display
- `description`: <class 'str'> - Status description
- `is_final`: <class 'bool'> - Whether this status marks task as done

### Category

Task category for organization and filtering

**Fields**:

- `id`: typing.Optional[beanie.odm.fields.PydanticObjectId] - MongoDB document ObjectID
- `revision_id`: typing.Optional[uuid.UUID] - None
- `name`: <class 'str'> - Category name
- `color`: <class 'str'> - Hex color for UI display
- `icon`: <class 'str'> - Icon name (e.g., 'work', 'home')
- `description`: <class 'str'> - Category description
- `created_at`: <class 'datetime.datetime'> - None
- `updated_at`: <class 'datetime.datetime'> - None

### Alarm

Reminder alarm for a task with optional recurrence

**Fields**:

- `id`: typing.Optional[beanie.odm.fields.PydanticObjectId] - MongoDB document ObjectID
- `revision_id`: typing.Optional[uuid.UUID] - None
- `task_id`: <class 'str'> - ID of task this alarm is for
- `alarm_time`: <class 'datetime.datetime'> - When to trigger the alarm
- `recurrence`: <enum 'RecurrencePattern'> - Alarm recurrence pattern
- `enabled`: <class 'bool'> - Whether alarm is active
- `last_triggered`: typing.Optional[datetime.datetime] - Last time this alarm was triggered
- `created_at`: <class 'datetime.datetime'> - None
- `updated_at`: <class 'datetime.datetime'> - None

### Task

Task item with dependencies, subtasks, and priority

**Fields**:

- `id`: typing.Optional[beanie.odm.fields.PydanticObjectId] - MongoDB document ObjectID
- `revision_id`: typing.Optional[uuid.UUID] - None
- `title`: <class 'str'> - Task title
- `description`: <class 'str'> - Detailed task description
- `context`: <class 'str'> - Context or notes for the task
- `status`: <enum 'TaskStatusEnum'> - Current task status
- `importance_rate`: <class 'int'> - Importance rating (0-5)
- `category_id`: typing.Optional[str] - ID of task category
- `date`: <class 'src.models.date.DateRange'> - Task start and finish dates
- `dependencies`: list[beanie.odm.fields.Link[src.models.task.Task]] - Tasks that must complete before this one starts
- `subtasks`: list[beanie.odm.fields.BackLink[src.models.task.Task]] - Tasks that are part of this task (populated automatically)
- `created_at`: <class 'datetime.datetime'> - None
- `updated_at`: <class 'datetime.datetime'> - None

**Relationships**:
- has many `Task` via `dependencies`
- has many `Task` via `subtasks`
