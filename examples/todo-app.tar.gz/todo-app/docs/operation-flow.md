# Operation Flow Graph

```mermaid
graph LR
    TaskStatus["TaskStatus"]
    Category["Category"]
    Alarm["Alarm"]
    Task["Task"]
    Task -->|tasks.analysis.check_needed| Task
    Task -->|tasks.analysis.next_by_urgency| Task
    Task -->|tasks.analysis.next_by_importance| Task
    Task -->|tasks.analysis.next_combined| Task
    Task -->|tasks.loader.markdown| Task
    Task -->|tasks.loader.json| Task
    Task -->|tasks.loader.code_todos| Task
```

## Legend

- **Nodes**: Data models (@datamodel decorated classes)
- **Edges**: Operations (@operation decorated functions)
- **Labels**: Operation names

## Operations Detail

### tasks.analysis.check_needed

**Description**: Find tasks with all dependencies completed and ready to start
**Category**: task-analysis
**Input Models**: Task
**Output Models**: Task

### tasks.analysis.next_by_urgency

**Description**: Get next task sorted by urgency (due date proximity)
**Category**: task-prioritization
**Input Models**: Task
**Output Models**: Task

### tasks.analysis.next_by_importance

**Description**: Get next task sorted by importance rating
**Category**: task-prioritization
**Input Models**: Task
**Output Models**: Task

### tasks.analysis.next_combined

**Description**: Get next task using combined urgency×importance score with heap sort
**Category**: task-prioritization
**Input Models**: Task
**Output Models**: Task

### tasks.loader.markdown

**Description**: Load tasks from Markdown with checkboxes (- [ ] task)
**Category**: task-import
**Input Models**: Task
**Output Models**: Task

### tasks.loader.json

**Description**: Load tasks from JSON array with task objects
**Category**: task-import
**Input Models**: Task
**Output Models**: Task

### tasks.loader.code_todos

**Description**: Extract TODO/FIXME from code comments
**Category**: task-import
**Input Models**: Task
**Output Models**: Task
