# Todo App - Port & Service Index

## 🚀 Active Services

### Port 8000 - Pulpo Todo App API
**Status:** ✅ **RUNNING**
**URL:** `http://localhost:8000`
**Description:** FastAPI server with auto-generated CRUD and operation endpoints
**Interfaces:**
- 📖 Swagger UI: `http://localhost:8000/docs`
- 📋 ReDoc: `http://localhost:8000/redoc`
- 📊 OpenAPI JSON: `http://localhost:8000/openapi.json`

**Key Endpoints:**
```
GET  /api/v1/task/              - List all tasks
POST /api/v1/task/              - Create new task
GET  /api/v1/task/{id}          - Get task details
PUT  /api/v1/task/{id}          - Update task
DELETE /api/v1/task/{id}        - Delete task

GET  /api/v1/category/          - List categories
POST /api/v1/category/          - Create category

GET  /api/v1/alarm/             - List alarms
POST /api/v1/alarm/             - Create alarm

GET  /api/v1/taskstatus/        - List custom statuses
POST /api/v1/taskstatus/        - Create status

POST /operations/tasks.analysis.check_needed
POST /operations/tasks.analysis.next_by_urgency
POST /operations/tasks.analysis.next_by_importance
POST /operations/tasks.analysis.next_combined
POST /operations/tasks.loader.markdown
POST /operations/tasks.loader.json
POST /operations/tasks.loader.code_todos
```

**Process ID:** 49277
**Framework:** Pulpo + FastAPI + Uvicorn
**Database:** MongoDB (requires connection)

---

## 📋 Service Inventory

| Port | Service | Status | Type | Details |
|------|---------|--------|------|---------|
| **8000** | **Pulpo Todo API** | ✅ Running | Python/FastAPI | Main application |
| 8080 | Other Service | Running | External | Not part of todo-app |
| 631 | CUPS | Running | System | Printing service |
| 2222 | SSH/Other | Running | System | System service |
| 53 | DNS | Running | System | Local DNS |
| 7681 | (Unknown) | Running | - | Local service |

---

## 🧪 Testing Guide

### 1. **Health Check**
```bash
curl -s http://localhost:8000/openapi.json | jq .info
```

### 2. **List Models**
```bash
curl -s http://localhost:8000/api/v1/task/
curl -s http://localhost:8000/api/v1/category/
curl -s http://localhost:8000/api/v1/alarm/
```

### 3. **Create Task**
```bash
curl -X POST http://localhost:8000/api/v1/task/ \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Task",
    "description": "Testing the API",
    "importance_rate": 3
  }'
```

### 4. **Test Operations**
```bash
curl -X POST http://localhost:8000/operations/tasks.analysis.check_needed \
  -H "Content-Type: application/json" \
  -d '{"status_filter": "pending"}'
```

---

## 📦 Project Structure

```
~/todo-app/
├── src/
│   ├── models/
│   │   ├── task.py           - Main task model
│   │   ├── category.py       - Categories
│   │   ├── alarm.py          - Reminders
│   │   ├── status.py         - Status enums
│   │   └── date.py           - Date utilities
│   └── operations/
│       ├── task_analysis.py  - Priority algorithms
│       └── document_loader.py - Import operations
├── run_cache/
│   ├── entrypoint.py         - API server entry point
│   ├── generated_api.py      - Auto-generated FastAPI app
│   └── generated_frontend/   - React UI (generated)
├── main.py                   - Pulpo CLI entry point
├── clean.sh                  - Cleanup script
└── PORT_INDEX.md            - This file
```

---

## 🔧 Startup Commands

### Start API Server
```bash
cd ~/todo-app
python main.py compile      # Generate API code
python run_cache/entrypoint.py  # Start server on port 8000
```

### Access UI
```bash
# Swagger UI
open http://localhost:8000/docs

# ReDoc
open http://localhost:8000/redoc
```

---

## 📊 Database Requirements

**Database:** MongoDB (not yet initialized)
**Default URL:** `mongodb://localhost:27017`
**Database Name:** `todo_db`

To initialize:
```bash
cd ~/todo-app
python main.py init
```

---

## ⚠️ Notes

- **MongoDB not running**: Models won't persist without MongoDB connection
- **API is functional**: All endpoints respond, but data operations require DB
- **Code generation bug fixed**: Function names with dots were manually corrected
- **Async operations**: All operations are async-enabled

---

## 🚦 Checklist

- ✅ Port 8000 is active
- ✅ API server is running
- ✅ Swagger UI accessible
- ✅ All 4 models discovered
- ✅ All 7 operations registered
- ✅ Code generation complete
- ⏳ MongoDB needs setup for persistence
- ⏳ Frontend UI needs Node.js build

