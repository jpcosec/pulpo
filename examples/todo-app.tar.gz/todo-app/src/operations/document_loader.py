"""Document loaders for importing tasks from various formats."""

import json
import re
from typing import Optional

from pydantic import BaseModel, Field

from core.decorators import operation
from ..models.task import Task
from ..models.date import DateRange


class LoadDocumentInput(BaseModel):
    """Base input for document loading operations."""

    content: str = Field(..., description="Document content to parse")
    category_id: Optional[str] = Field(default=None, description="Category ID for created tasks")
    importance_rate: int = Field(default=0, ge=0, le=5, description="Default importance for loaded tasks")


class LoadOutput(BaseModel):
    """Output from document loading."""

    created_count: int = Field(..., description="Number of tasks created")
    message: str = Field(..., description="Loading result message")
    task_ids: list[str] = Field(..., description="IDs of created tasks")


@operation(
    name="tasks.loader.markdown",
    description="Load tasks from Markdown with checkboxes (- [ ] task)",
    category="task-import",
    inputs=LoadDocumentInput,
    outputs=LoadOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def load_markdown(input_data: LoadDocumentInput) -> LoadOutput:
    """Parse Markdown checkboxes and create tasks.

    Simple 3-step loader:
    1. Find lines with '- [ ]' or '- [x]' patterns
    2. Extract task titles (text after checkbox)
    3. Create Task documents for each
    """
    # Step 1: Find all checkbox lines
    pattern = r"^- \[([ xX])\]\s+(.+)$"
    matches = re.findall(pattern, input_data.content, re.MULTILINE)

    # Step 2: Extract titles and check status
    tasks_data = [
        {"title": title.strip(), "completed": status.lower() == "x"}
        for status, title in matches
    ]

    # Step 3: Create Task documents
    created_ids = []
    for task_data in tasks_data:
        task = Task(
            title=task_data["title"],
            status="completed" if task_data["completed"] else "pending",
            category_id=input_data.category_id,
            importance_rate=input_data.importance_rate,
            date=DateRange()
        )
        result = await task.insert()
        created_ids.append(str(result.id))

    return LoadOutput(
        created_count=len(created_ids),
        message=f"Loaded {len(created_ids)} tasks from Markdown",
        task_ids=created_ids
    )


@operation(
    name="tasks.loader.json",
    description="Load tasks from JSON array with task objects",
    category="task-import",
    inputs=LoadDocumentInput,
    outputs=LoadOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def load_json(input_data: LoadDocumentInput) -> LoadOutput:
    """Parse JSON task array and create documents.

    Simple 3-step loader:
    1. Parse JSON content to array
    2. Validate each task has at least 'title'
    3. Create Task documents with provided fields
    """
    try:
        # Step 1: Parse JSON
        data = json.loads(input_data.content)
        tasks_list = data if isinstance(data, list) else [data]

        # Step 2: Validate and prepare tasks
        valid_tasks = [
            t for t in tasks_list
            if isinstance(t, dict) and "title" in t
        ]

        # Step 3: Create Task documents
        created_ids = []
        for task_data in valid_tasks:
            task = Task(
                title=task_data.get("title", "Untitled"),
                description=task_data.get("description", ""),
                status=task_data.get("status", "pending"),
                importance_rate=task_data.get("importance_rate", input_data.importance_rate),
                category_id=input_data.category_id or task_data.get("category_id"),
                date=DateRange(
                    start=task_data.get("start"),
                    finish=task_data.get("finish")
                ) if task_data.get("start") or task_data.get("finish") else DateRange()
            )
            result = await task.insert()
            created_ids.append(str(result.id))

        return LoadOutput(
            created_count=len(created_ids),
            message=f"Loaded {len(created_ids)} tasks from JSON",
            task_ids=created_ids
        )

    except json.JSONDecodeError as e:
        return LoadOutput(
            created_count=0,
            message=f"Invalid JSON: {str(e)}",
            task_ids=[]
        )


class CodeTodoInput(BaseModel):
    """Input for scanning code comments."""

    content: str = Field(..., description="Code content to scan")
    file_path: str = Field(default="untitled.py", description="Source file path for context")
    category_id: Optional[str] = Field(default=None, description="Category ID for created tasks")


@operation(
    name="tasks.loader.code_todos",
    description="Extract TODO/FIXME from code comments",
    category="task-import",
    inputs=CodeTodoInput,
    outputs=LoadOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def extract_code_todos(input_data: CodeTodoInput) -> LoadOutput:
    """Extract TODO and FIXME comments from code.

    Simple 3-step loader:
    1. Find lines with 'TODO:' or 'FIXME:' patterns
    2. Extract comment text and line numbers
    3. Create Task documents with file context
    """
    # Step 1: Find TODO/FIXME patterns
    pattern = r"^.*?(TODO|FIXME):\s*(.+)$"
    matches = re.findall(pattern, input_data.content, re.MULTILINE)

    # Step 2: Extract data and add context
    todos = [
        {
            "title": f"[{tag}] {text.strip()}",
            "context": f"In {input_data.file_path}",
            "importance": 4 if tag == "FIXME" else 2
        }
        for tag, text in matches
    ]

    # Step 3: Create Task documents
    created_ids = []
    for todo in todos:
        task = Task(
            title=todo["title"],
            context=todo["context"],
            importance_rate=todo["importance"],
            category_id=input_data.category_id,
            date=DateRange()
        )
        result = await task.insert()
        created_ids.append(str(result.id))

    return LoadOutput(
        created_count=len(created_ids),
        message=f"Extracted {len(created_ids)} TODOs/FIXMEs from code",
        task_ids=created_ids
    )
