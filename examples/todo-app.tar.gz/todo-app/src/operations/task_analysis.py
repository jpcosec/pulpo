"""Task analysis and prioritization operations."""

import heapq
from typing import Optional

from pydantic import BaseModel, Field

from core.decorators import operation
from ..models.task import Task


class CheckNeededTasksInput(BaseModel):
    """Input for checking tasks that can be started."""

    status_filter: Optional[str] = Field(
        default="pending",
        description="Only check tasks with this status (pending, in_progress, etc.)"
    )


class TaskSummary(BaseModel):
    """Lightweight task summary for responses."""

    task_id: str = Field(..., description="Task ID")
    title: str = Field(..., description="Task title")
    importance_rate: int = Field(..., description="Importance rating 0-5")
    urgency: float = Field(..., description="Calculated urgency 0-10")


class CheckNeededTasksOutput(BaseModel):
    """Output for checking needed tasks."""

    tasks: list[TaskSummary] = Field(..., description="Tasks ready to start")
    count: int = Field(..., description="Number of tasks ready")
    message: str = Field(..., description="Status message")


@operation(
    name="tasks.analysis.check_needed",
    description="Find tasks with all dependencies completed and ready to start",
    category="task-analysis",
    inputs=CheckNeededTasksInput,
    outputs=CheckNeededTasksOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def check_needed_tasks(input_data: CheckNeededTasksInput) -> CheckNeededTasksOutput:
    """Check which tasks are ready to start (all dependencies completed).

    A task is 'needed' if:
    - Its status matches the filter
    - All its dependencies are completed
    """
    # Build query
    query = {"status": input_data.status_filter or "pending"}

    # Get all tasks matching status
    available_tasks = await Task.find(query).to_list()

    needed = []
    for task in available_tasks:
        # Check if all dependencies are completed
        if not task.dependencies:
            # No dependencies, task is ready
            needed.append(task)
        else:
            # Check each dependency
            all_deps_done = True
            for dep_link in task.dependencies:
                dep_task = await dep_link.fetch()
                if dep_task.status != "completed":
                    all_deps_done = False
                    break

            if all_deps_done:
                needed.append(task)

    # Build response
    task_summaries = [
        TaskSummary(
            task_id=str(task.id),
            title=task.title,
            importance_rate=task.importance_rate,
            urgency=task.urgency
        )
        for task in needed
    ]

    return CheckNeededTasksOutput(
        tasks=task_summaries,
        count=len(task_summaries),
        message=f"Found {len(task_summaries)} tasks ready to start"
    )


class NextTaskInput(BaseModel):
    """Input for getting next task recommendation."""

    limit: int = Field(default=5, ge=1, le=20, description="Max tasks to return")
    exclude_ids: list[str] = Field(default_factory=list, description="Task IDs to exclude")


class NextTaskOutput(BaseModel):
    """Output with recommended next tasks."""

    tasks: list[TaskSummary] = Field(..., description="Recommended tasks in order")
    message: str = Field(..., description="Recommendation reasoning")


@operation(
    name="tasks.analysis.next_by_urgency",
    description="Get next task sorted by urgency (due date proximity)",
    category="task-prioritization",
    inputs=NextTaskInput,
    outputs=NextTaskOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def next_by_urgency(input_data: NextTaskInput) -> NextTaskOutput:
    """Get tasks sorted by urgency (highest first).

    Urgency is calculated based on due date proximity:
    - Overdue = 10.0
    - Due within 1 day = 8-10
    - Due within 1 week = 5-8
    - Due within 1 month = 1-5
    - No due date = 0.5
    """
    # Get pending/in_progress tasks excluding specified IDs
    query = {
        "status": {"$in": ["pending", "in_progress"]},
        "_id": {"$nin": [id for id in input_data.exclude_ids]}
    }

    tasks = await Task.find(query).to_list()

    # Sort by urgency descending
    sorted_tasks = sorted(tasks, key=lambda t: t.urgency, reverse=True)
    sorted_tasks = sorted_tasks[:input_data.limit]

    task_summaries = [
        TaskSummary(
            task_id=str(task.id),
            title=task.title,
            importance_rate=task.importance_rate,
            urgency=task.urgency
        )
        for task in sorted_tasks
    ]

    return NextTaskOutput(
        tasks=task_summaries,
        message="Tasks sorted by urgency (due date proximity)"
    )


@operation(
    name="tasks.analysis.next_by_importance",
    description="Get next task sorted by importance rating",
    category="task-prioritization",
    inputs=NextTaskInput,
    outputs=NextTaskOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def next_by_importance(input_data: NextTaskInput) -> NextTaskOutput:
    """Get tasks sorted by importance rating (highest first)."""
    query = {
        "status": {"$in": ["pending", "in_progress"]},
        "_id": {"$nin": [id for id in input_data.exclude_ids]}
    }

    tasks = await Task.find(query).to_list()

    # Sort by importance_rate descending
    sorted_tasks = sorted(tasks, key=lambda t: t.importance_rate, reverse=True)
    sorted_tasks = sorted_tasks[:input_data.limit]

    task_summaries = [
        TaskSummary(
            task_id=str(task.id),
            title=task.title,
            importance_rate=task.importance_rate,
            urgency=task.urgency
        )
        for task in sorted_tasks
    ]

    return NextTaskOutput(
        tasks=task_summaries,
        message="Tasks sorted by importance rating"
    )


@operation(
    name="tasks.analysis.next_combined",
    description="Get next task using combined urgency×importance score with heap sort",
    category="task-prioritization",
    inputs=NextTaskInput,
    outputs=NextTaskOutput,
    models_in=["Task"],
    models_out=["Task"]
)
async def next_combined(input_data: NextTaskInput) -> NextTaskOutput:
    """Get tasks sorted by combined score (urgency × importance).

    Uses heap sort for efficient ordering when many tasks exist.
    Higher score = higher priority.

    Formula: combined_score = urgency × importance_rate / 5
    This normalizes importance (0-5) so it scales with urgency (0-10).
    """
    query = {
        "status": {"$in": ["pending", "in_progress"]},
        "_id": {"$nin": [id for id in input_data.exclude_ids]}
    }

    tasks = await Task.find(query).to_list()

    # Calculate combined scores and create heap (using negative for max-heap)
    heap = []
    for task in tasks:
        combined_score = task.urgency * (task.importance_rate / 5.0)
        # Negative for max-heap behavior
        heapq.heappush(heap, (-combined_score, str(task.id), task))

    # Extract top N items from heap
    top_tasks = []
    for _ in range(min(input_data.limit, len(heap))):
        if heap:
            _, _, task = heapq.heappop(heap)
            top_tasks.append(task)

    task_summaries = [
        TaskSummary(
            task_id=str(task.id),
            title=task.title,
            importance_rate=task.importance_rate,
            urgency=task.urgency
        )
        for task in top_tasks
    ]

    return NextTaskOutput(
        tasks=task_summaries,
        message="Tasks sorted by combined urgency×importance score (heap sorted)"
    )
