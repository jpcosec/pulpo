"""Task status definitions."""

from enum import Enum

from beanie import Document
from pydantic import Field

from core.decorators import datamodel


class TaskStatusEnum(str, Enum):
    """Built-in task status values."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ARCHIVED = "archived"


@datamodel(
    name="TaskStatus",
    description="Custom task status for user-defined workflows",
    tags=["status", "workflow"]
)
class TaskStatus(Document):
    """Custom task status definition allowing user-defined statuses."""

    name: str = Field(..., description="Status name (e.g., 'On Hold', 'Blocked')")
    color: str = Field(default="#808080", description="Hex color for UI display")
    description: str = Field(default="", description="Status description")
    is_final: bool = Field(
        default=False,
        description="Whether this status marks task as done"
    )

    class Settings:
        name = "task_statuses"
