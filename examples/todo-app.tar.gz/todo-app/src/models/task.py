"""Task model with graph relationships."""

from datetime import datetime
from typing import Optional

from beanie import Document, Link, BackLink
from pydantic import Field, computed_field

from core.decorators import datamodel
from .date import DateRange
from .status import TaskStatusEnum


@datamodel(
    name="Task",
    description="Task item with dependencies, subtasks, and priority",
    tags=["task", "todo"]
)
class Task(Document):
    """Task representing a work item with graph relationships."""

    # Basic fields
    title: str = Field(..., description="Task title")
    description: str = Field(default="", description="Detailed task description")
    context: str = Field(default="", description="Context or notes for the task")

    # Status and priority
    status: TaskStatusEnum = Field(
        default=TaskStatusEnum.PENDING,
        description="Current task status"
    )
    importance_rate: int = Field(
        default=0,
        ge=0,
        le=5,
        description="Importance rating (0-5)"
    )

    # References
    category_id: Optional[str] = Field(
        default=None,
        description="ID of task category"
    )

    # Embedded date range
    date: DateRange = Field(
        default_factory=DateRange,
        description="Task start and finish dates"
    )

    # Graph relationships
    dependencies: list[Link["Task"]] = Field(
        default_factory=list,
        description="Tasks that must complete before this one starts"
    )
    subtasks: list[BackLink["Task"]] = Field(
        default=[],
        description="Tasks that are part of this task (populated automatically)"
    )

    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    @computed_field
    @property
    def urgency(self) -> float:
        """Calculate urgency score based on due date proximity (0-10 scale).

        - 10.0 if overdue
        - 8-10 if due within 1 day
        - 5-8 if due within 1 week
        - 1-5 if due within 1 month
        - 0.5 if due later or no due date
        """
        if self.date.finish is None:
            return 0.5

        if self.date.is_overdue():
            return 10.0

        days_left = self.date.days_until_due()
        if days_left is None:
            return 0.5
        elif days_left == 0:
            return 9.5
        elif days_left < 7:
            return 5.0 + min(3.0, 3.0 * (1 - days_left / 7))
        elif days_left < 30:
            return 1.0 + min(4.0, 4.0 * (1 - days_left / 30))
        else:
            return 0.5

    class Settings:
        name = "tasks"

    class Config:
        json_schema_extra = {
            "example": {
                "title": "Complete project report",
                "description": "Finish Q4 analysis and recommendations",
                "context": "For stakeholder meeting",
                "status": "in_progress",
                "importance_rate": 4,
                "date": {
                    "start": "2025-11-16T10:00:00",
                    "finish": "2025-11-20T17:00:00"
                }
            }
        }
