"""Task category model."""

from datetime import datetime

from beanie import Document
from pydantic import Field

from core.decorators import datamodel


@datamodel(
    name="Category",
    description="Task category for organization and filtering",
    tags=["category", "organization"]
)
class Category(Document):
    """Category for grouping related tasks."""

    name: str = Field(..., description="Category name")
    color: str = Field(default="#0066CC", description="Hex color for UI display")
    icon: str = Field(default="folder", description="Icon name (e.g., 'work', 'home')")
    description: str = Field(default="", description="Category description")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "categories"
