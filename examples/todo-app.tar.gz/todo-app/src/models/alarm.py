"""Alarm model for task reminders."""

from datetime import datetime
from enum import Enum
from typing import Optional

from beanie import Document
from pydantic import Field

from core.decorators import datamodel


class RecurrencePattern(str, Enum):
    """Recurrence patterns for alarms."""

    ONCE = "once"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


@datamodel(
    name="Alarm",
    description="Reminder alarm for a task with optional recurrence",
    tags=["alarm", "reminder"]
)
class Alarm(Document):
    """Task alarm/reminder with recurrence support."""

    task_id: str = Field(..., description="ID of task this alarm is for")
    alarm_time: datetime = Field(..., description="When to trigger the alarm")
    recurrence: RecurrencePattern = Field(
        default=RecurrencePattern.ONCE,
        description="Alarm recurrence pattern"
    )
    enabled: bool = Field(default=True, description="Whether alarm is active")
    last_triggered: Optional[datetime] = Field(
        default=None,
        description="Last time this alarm was triggered"
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Settings:
        name = "alarms"
