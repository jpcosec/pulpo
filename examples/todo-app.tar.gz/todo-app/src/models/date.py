"""Date and time models for tasks."""

from datetime import datetime, timedelta
from typing import Optional

from pydantic import BaseModel, Field


class DateRange(BaseModel):
    """Date range with optional start and finish times."""

    start: Optional[datetime] = Field(
        default=None,
        description="Task start date/time"
    )
    finish: Optional[datetime] = Field(
        default=None,
        description="Task finish/due date/time"
    )

    def is_overdue(self) -> bool:
        """Check if task is overdue (finish date passed and not completed)."""
        if self.finish is None:
            return False
        return datetime.utcnow() > self.finish

    def days_until_due(self) -> Optional[int]:
        """Days remaining until due date, or None if no due date."""
        if self.finish is None:
            return None
        delta = self.finish - datetime.utcnow()
        return max(0, delta.days)

    def is_due_soon(self, days: int = 1) -> bool:
        """Check if task is due within specified number of days."""
        if self.finish is None:
            return False
        due_threshold = datetime.utcnow() + timedelta(days=days)
        return self.finish <= due_threshold
