#!/bin/bash

# Clean script - Resets folder to current state by backing up whitelisted items
# Usage: bash clean.sh
#
# Safe backup/restore approach:
# 1. Back up whitelisted items
# 2. Delete everything
# 3. Restore from backup
# 4. Verify restoration
# 5. Clean backup

set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${SCRIPT_DIR}/.clean_backup_$$"

echo "🧹 Cleaning todo-app folder to current state..."
echo ""

# Whitelist - items to preserve
WHITELIST=(
    ".git"
    "clean.sh"
    "CLEANUP.md"
    "README.md"
    ".gitignore"
    "src"
)

echo "✅ Whitelist of items to preserve:"
for item in "${WHITELIST[@]}"; do
    echo "  - $item"
done
echo ""

# Identify items to remove
echo "📋 Scanning for files/folders to remove..."
REMOVE_COUNT=0

for item in "$SCRIPT_DIR"/* "$SCRIPT_DIR"/.* ; do
    [[ ! -e "$item" ]] && continue
    basename_item=$(basename "$item" 2>/dev/null)

    # Skip . and .. and backup folder
    [[ "$basename_item" == "." || "$basename_item" == ".." ]] && continue
    [[ "$basename_item" == ".clean_backup"* ]] && continue

    # Check if in whitelist
    IN_WHITELIST=0
    for whitelisted in "${WHITELIST[@]}"; do
        [[ "$basename_item" == "$whitelisted" ]] && IN_WHITELIST=1 && break
    done

    [[ $IN_WHITELIST -eq 0 ]] && echo "  - $basename_item" && ((REMOVE_COUNT++))
done

echo ""
if [[ $REMOVE_COUNT -eq 0 ]]; then
    echo "✅ Already clean!"
    exit 0
fi

echo "Found $REMOVE_COUNT item(s) to remove"
echo ""

# Confirm
read -p "Continue? (y/N) " -n 1 -r
echo
[[ ! $REPLY =~ ^[Yy]$ ]] && echo "❌ Cancelled." && exit 0

# Backup
echo "📦 Backing up whitelisted items..."
mkdir -p "$BACKUP_DIR"

for item in "${WHITELIST[@]}"; do
    [[ -e "$SCRIPT_DIR/$item" ]] && cp -rp "$SCRIPT_DIR/$item" "$BACKUP_DIR/" && echo "  ✓ $item"
done

echo ""
echo "🗑️  Deleting everything..."
cd "$SCRIPT_DIR"

# Remove all items recursively
find . -maxdepth 1 -mindepth 1 ! -name ".clean_backup*" -exec rm -rf {} + 2>/dev/null || true

echo "  ✓ Done"

# Restore
echo ""
echo "📥 Restoring whitelisted items..."
cd "$SCRIPT_DIR"

for item in "${WHITELIST[@]}"; do
    if [[ -d "$BACKUP_DIR/$item" ]] || [[ -f "$BACKUP_DIR/$item" ]]; then
        cp -rp "$BACKUP_DIR/$item" "$SCRIPT_DIR/"
        echo "  ✓ $item"
    fi
done

# Cleanup backup
echo ""
echo "🧹 Removing backup..."
rm -rf "$BACKUP_DIR"
echo "  ✓ Done"

echo ""
echo "✅ Cleanup complete!"
echo ""
echo "📊 Contents:"
ls -la "$SCRIPT_DIR" | tail -n +4
