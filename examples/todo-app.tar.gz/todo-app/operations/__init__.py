"""Todo List Example - Operations.

Operations for managing todo items.
"""
